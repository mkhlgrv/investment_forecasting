source('lib.R')

load('shinydata.RData')
